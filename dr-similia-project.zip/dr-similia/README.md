# Dr. Similia — BHMS AI Tutor

AI-powered doubt solver for BHMS medical students.
Built for SahAI for Shiksha Hackathon 2026.

## Deploy on Vercel (Step by Step)

### 1. Upload to GitHub
- Create a new GitHub repository named `dr-similia`
- Upload ALL these files keeping the same folder structure

### 2. Set Environment Variable on Vercel
- Go to your Vercel project → Settings → Environment Variables
- Add:
  - Name: `ANTHROPIC_API_KEY`
  - Value: your Anthropic API key (get from console.anthropic.com)

### 3. Deploy
- Connect GitHub repo to Vercel
- Click Deploy

## Project Structure
```
dr-similia/
├── pages/
│   ├── index.jsx        ← Main chatbot UI
│   ├── _app.jsx         ← App wrapper
│   └── api/
│       └── chat.js      ← AI API route
├── styles/
│   ├── Home.module.css  ← Chatbot styles
│   └── globals.css      ← Global styles
├── package.json
└── next.config.js
```

## Tech Stack
- Next.js 14
- Anthropic Claude API
- CSS Modules
