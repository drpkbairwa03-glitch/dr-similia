import { useState, useRef, useEffect } from "react";
import styles from "../styles/Home.module.css";

const SUGGESTED = [
  "Explain Aphorism 1 of Organon",
  "What is Similimum?",
  "How to select potency?",
  "Keynotes of Aconite",
  "Steps of Case Taking",
  "Explain Krebs Cycle",
  "What is Law of Similia?",
  "Hering's Law of Cure",
];

function renderContent(text) {
  return text.split("\n").map((line, i) => {
    const html = line
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>");
    return (
      <p
        key={i}
        dangerouslySetInnerHTML={{ __html: html || "&nbsp;" }}
        className={
          line.startsWith("•") || /^\d+\./.test(line)
            ? styles.listLine
            : styles.textLine
        }
      />
    );
  });
}

export default function Home() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hello! 👋 I am **Dr. Similia** — your personal BHMS AI Tutor!\n\nAsk me anything about **Organon of Medicine**, **Materia Medica**, **Homoeopathic Pharmacy**, **Physiology**, or any other BHMS subject.\n\nI'm here to help you study smarter! 😊",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = async (text) => {
    const question = (text || input).trim();
    if (!question || loading) return;
    setInput("");
    setError("");

    const newMessages = [...messages, { role: "user", content: question }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      const data = await res.json();

      if (data.error) {
        setError("Error: " + data.error);
        setMessages(newMessages);
      } else {
        setMessages([...newMessages, { role: "assistant", content: data.reply }]);
      }
    } catch {
      setError("Network error. Please check your connection.");
      setMessages(newMessages);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  return (
    <div className={styles.app}>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.logo}>⚕️</div>
        <div className={styles.headerText}>
          <h1>Dr. Similia</h1>
          <p>BHMS AI Tutor • Powered by AI</p>
        </div>
        <div className={styles.badges}>
          <span className={styles.badge}>Organon</span>
          <span className={styles.badge}>Materia Medica</span>
          <span className={styles.badge}>Pharmacy</span>
        </div>
      </header>

      {/* Chat */}
      <main className={styles.chat}>
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`${styles.msgRow} ${
              msg.role === "user" ? styles.userRow : styles.botRow
            }`}
          >
            {msg.role === "assistant" && (
              <div className={styles.avatar}>⚕️</div>
            )}
            <div
              className={`${styles.bubble} ${
                msg.role === "user" ? styles.userBubble : styles.botBubble
              }`}
            >
              {renderContent(msg.content)}
            </div>
          </div>
        ))}

        {loading && (
          <div className={`${styles.msgRow} ${styles.botRow}`}>
            <div className={styles.avatar}>⚕️</div>
            <div className={`${styles.bubble} ${styles.botBubble}`}>
              <div className={styles.dots}>
                <span /><span /><span />
              </div>
            </div>
          </div>
        )}

        {error && <p className={styles.error}>{error}</p>}
        <div ref={bottomRef} />
      </main>

      {/* Suggestions */}
      {messages.length <= 2 && (
        <div className={styles.suggestions}>
          {SUGGESTED.map((q) => (
            <button key={q} onClick={() => send(q)} className={styles.chip}>
              {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <footer className={styles.footer}>
        <div className={styles.inputBox}>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask any BHMS question... (Organon, Materia Medica, Pharmacy)"
            rows={1}
            className={styles.textarea}
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || loading}
            className={`${styles.sendBtn} ${
              input.trim() && !loading ? styles.sendActive : ""
            }`}
          >
            ➤
          </button>
        </div>
        <p className={styles.footer_note}>
          Dr. Similia • SahAI for Shiksha Hackathon 2026 • Wadhwani AI + Google.org
        </p>
      </footer>
    </div>
  );
}
