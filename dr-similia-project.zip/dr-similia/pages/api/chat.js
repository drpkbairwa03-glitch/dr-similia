export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { messages } = req.body;

  const SYSTEM_PROMPT = `You are Dr. Similia, an expert AI tutor for BHMS (Bachelor of Homoeopathic Medicine and Surgery) students in India.

Your role:
- Answer questions about BHMS subjects: Organon of Medicine, Materia Medica, Homoeopathic Pharmacy, Physiology, Biochemistry, Pathology, Surgery, Obstetrics & Gynaecology
- Respond in clear English, simple and easy to understand for medical students
- Give structured, exam-focused answers
- Use bullet points and numbered lists for clarity
- Always highlight KEY TERMS in bold
- End every response with: "Any more doubts? Ask away! 😊"

Be encouraging, friendly, and supportive like a senior student helping a junior.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: messages,
      }),
    });

    const data = await response.json();

    if (data.error) {
      return res.status(500).json({ error: data.error.message });
    }

    const reply = data.content?.[0]?.text || "Sorry, something went wrong. Please try again!";
    res.status(200).json({ reply });
  } catch (error) {
    res.status(500).json({ error: "Server error: " + error.message });
  }
}
